/**
@author Marcos Rodrigo Ambrocio Larios 231140
 @version 1.0
  Este programa proporciona ayuda para comprar boletos para Tomorrowland , usando el Nombre, dpi, basandose en los
 tickets que se quieren comprar y en el presupuesto.
 */

/**
 * Verifica si el boleto es elegible para su compra.
 *
 * @return true si el boleto es elegible, false de lo contrario.
 */

import java.util.Random;
import java.util.Scanner;

public class algoritmoTicket {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingresa tu nombre");
        String nombre = scanner.nextLine();

        System.out.println("Ingresa tu DPI");
        int dpi = scanner.nextInt();

        System.out.println("Ingrea el número de tickets que quieres comprar");
        int numTickets = scanner.nextInt();

        System.out.println("Ingresa tu presupuesto");
        double presupuesto = scanner.nextDouble();

        Compraticket compra = new Compraticket(nombre, dpi, numTickets, presupuesto);

        Random random = new Random();
        int totalTickets = 60000;

        for (int i = 0; i < compra.numTickets; i++) {
            int ticketNumber = random.nextInt(totalTickets) + 1;
            int additionalNumber1 = random.nextInt(15000) + 1;
            int additionalNumber2 = random.nextInt(15000) + 1;
            Ticket ticket = new Ticket (ticketNumber, additionalNumber1, additionalNumber2);

            if (ticket.sePuedeComprar()) {
                int location = random.nextInt(3);
                double ticketPrice = 0;

                if (location == 0) {
                    ticketPrice = 400;
                } else if (location == 1) {
                    ticketPrice = 695;
                } else if (location == 2) {
                    ticketPrice = 2350;
                }
                if (compra.presupuesto >= ticketPrice) {
                    compra.presupuesto -= ticketPrice;
                    System.out.println("Felicidades, " + compra.nombre + "! Has comprado el ticket #" + ticket.ticketNumber +
                            " por $" + ticketPrice + " en Localidad " + (location + 1));
                } else {
                    System.out.println("Lo sentimos, " + compra.nombre + ". tu presupuesto no es suficiente para comprar el ticket #" + ticket.ticketNumber);
                }
            } else {
                System.out.println("Lo sentimos, " + compra.nombre + ". Ticket #" + ticket.ticketNumber + " no está disponible para su compra.");

            }
        }
    }
}

