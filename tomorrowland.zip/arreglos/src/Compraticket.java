import java.util.Random;
import java.util.Scanner;
/**
 * Esta clase representa la información de compra de boletos para Tomorrowland.
 * Permite a los usuarios comprar boletos y verificar su elegibilidad.
 */
public class Compraticket {
    String nombre;
    int dpi;
    int numTickets;
    double presupuesto;

            public Compraticket(String nombre, int dpi, int numTickets, double  presupuesto) {
                this.nombre = nombre;
                this.dpi =  dpi;
                this.numTickets = numTickets;
                this.presupuesto =  presupuesto;
            }


}
class Ticket {
    int ticketNumber;
    int additionalNumber1;
    int additionalNumber2;

    public Ticket(int ticketNumber, int additionalNumber1, int additionalNumber2) {
        this.ticketNumber = ticketNumber;
        this.additionalNumber1 = additionalNumber1;
        this.additionalNumber2 = additionalNumber2;
    }

    public boolean sePuedeComprar() {
        return (ticketNumber + additionalNumber1 + additionalNumber2) % 2 == 0;
    }
}

